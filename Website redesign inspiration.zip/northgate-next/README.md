# Northgate Consulting — Homepage

Next.js (App Router) + Tailwind CSS v4 + Framer Motion + TypeScript + Lucide React.
A faithful build of the Northgate homepage: hero, joy101-style curved media band,
McKinsey-style "Active Intelligence" editorial masonry, the four-phase engagement
model, an interactive sector-tabbed "Problems That Matter" section, CTA, and footer.

## Quick start

```bash
npm install
npm run dev
# open http://localhost:3000
```

> Requires Node 18.18+ (Node 20+ recommended).

## Stack

| Concern    | Choice |
|------------|--------|
| Framework  | Next.js 15, App Router |
| Styling    | Tailwind CSS v4 (CSS-first `@theme`, no `tailwind.config.js`) |
| Animation  | Framer Motion (scroll reveals + tab transitions) |
| Language   | TypeScript (strict) |
| Icons      | lucide-react |
| Fonts      | `next/font/google` — Lexend, Source Sans 3, Geist Mono |

## Project structure

```
app/
  globals.css        # Tailwind import + @theme brand tokens
  layout.tsx         # fonts (CSS vars) + <body> defaults + metadata
  page.tsx           # composes the seven sections
components/
  Arc.tsx            # reusable curved SVG dividers (hero / concaveTop / concaveBottom)
  Reveal.tsx         # 'use client' scroll-reveal wrapper (+ stagger variants)
  sections/
    Hero.tsx
    ProofBand.tsx          # curved media band
    ActiveIntelligence.tsx # featured + two compact signal cards
    HowWeEngage.tsx        # four phases
    ProblemsThatMatter.tsx # 'use client' — sector tabs
    CTA.tsx
    SiteFooter.tsx
lib/
  content.ts         # all copy data: SECTORS, PHASES (edit text here)
```

## Design tokens

Defined once in `app/globals.css` under `@theme`, available as Tailwind utilities:

| Token | Value | Utility examples |
|-------|-------|------------------|
| navy | `#0c1945` | `text-navy`, `bg-navy` |
| ink | `#070b1c` | `bg-ink` (page base) |
| panel | `#0b1330` | `bg-panel` (cards) |
| blue | `#3d5ad9` | `bg-blue`, `border-blue` |
| cyan | `#05aff2` | `text-cyan` (primary accent) |
| mute | `#8b97b5` | `text-mute` (body on dark) |
| telecom / healthcare / fintech | `#6f8bff` / `#34d8a6` / `#a78bfa` | sector accents |

Fonts map to `font-display` (Lexend), `font-body` (Source Sans 3), `font-mono` (Geist Mono).

## Swapping in real media

The hero and the "Active Intelligence" cards use **brand-gradient placeholders**
(SVG motifs on CSS gradients). To use real assets:

1. Drop images in `public/` (e.g. `public/media/boardroom.jpg`).
2. In `ProofBand.tsx`, replace each gradient `<div>` body with
   `<Image src="/media/…" alt="" fill className="object-cover" />`
   (import `Image from "next/image"`; keep the wrapper's `relative overflow-hidden`).
3. For the centre panel video, swap the play button for a `<video>` or a modal trigger.
4. Same pattern for the image panels in `ActiveIntelligence.tsx`.

## Editing content

All copy that repeats lives in `lib/content.ts` (`SECTORS`, `PHASES`). One-off
headlines live inline in their section component. Nav links, services, and footer
columns are plain arrays at the top of their respective files.

## Notes

- Only `Reveal.tsx` and `ProblemsThatMatter.tsx` are Client Components; everything
  else renders on the server.
- The curved dividers are pure SVG (`components/Arc.tsx`) — no images, fully responsive.
- `text-balance` is used on headlines for even line-wrapping (the symmetry pass).
