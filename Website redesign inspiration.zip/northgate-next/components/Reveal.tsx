"use client";

import { motion, type Variants } from "framer-motion";
import type { ReactNode } from "react";

const easeOut: [number, number, number, number] = [0.22, 1, 0.36, 1];

/**
 * Scroll-triggered fade + rise. Wrap any (server-rendered) markup with it.
 * Because children are passed through, the wrapped content can stay in a
 * Server Component while only this wrapper is client-side.
 */
export function Reveal({
  children,
  delay = 0,
  y = 24,
  className,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.6, delay, ease: easeOut }}
    >
      {children}
    </motion.div>
  );
}

/** Stagger container + item, for grids of cards. */
export const staggerParent: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12 } },
};

export const staggerItem: Variants = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: easeOut } },
};
