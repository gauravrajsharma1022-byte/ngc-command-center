/**
 * Sweeping joy101-style arc dividers, rendered as full-bleed SVG.
 * `fill` is the colour the arc paints (i.e. the colour it carves INTO the
 * neighbouring band). Heights use clamp() so the curve scales with viewport.
 */

type ArcVariant = "hero" | "concaveTop" | "concaveBottom";

const PATHS: Record<ArcVariant, { d: string; viewBox: string }> = {
  // ocean → next section (convex dip)
  hero: { d: "M0,120 L0,40 C460,128 980,128 1440,40 L1440,120 Z", viewBox: "0 0 1440 120" },
  // carves white DOWN into the top of a media band
  concaveTop: { d: "M0,0 L1440,0 L1440,5 C980,128 460,128 0,5 Z", viewBox: "0 0 1440 110" },
  // carves white UP into the bottom of a media band
  concaveBottom: { d: "M0,110 L1440,110 L1440,105 C980,-18 460,-18 0,105 Z", viewBox: "0 0 1440 110" },
};

export function Arc({
  variant,
  fill = "#ffffff",
  className,
  heightClass = "h-[clamp(56px,7vw,118px)]",
}: {
  variant: ArcVariant;
  fill?: string;
  className?: string;
  heightClass?: string;
}) {
  const { d, viewBox } = PATHS[variant];
  return (
    <div className={`leading-[0] ${className ?? ""}`}>
      <svg
        viewBox={viewBox}
        preserveAspectRatio="none"
        className={`block w-full ${heightClass}`}
      >
        <path d={d} fill={fill} />
      </svg>
    </div>
  );
}
