import { ArrowRight } from "lucide-react";
import { Arc } from "@/components/Arc";

const navItems = ["Who We Are", "What We Do", "Our Thinking"];

export function Hero() {
  return (
    <section
      className="relative flex min-h-screen flex-col text-white"
      style={{
        background:
          "radial-gradient(125% 80% at 72% 8%,rgba(5,175,242,0.20),transparent 58%),radial-gradient(110% 130% at 12% 100%,rgba(61,90,217,0.30),transparent 55%),linear-gradient(178deg,#0a1640 0%,#0c2350 42%,#0a1c4a 72%,#0b1846 100%)",
      }}
    >
      {/* horizon sheen */}
      <div
        className="pointer-events-none absolute inset-x-0 top-[34%] h-[32%]"
        style={{
          background:
            "linear-gradient(180deg,transparent,rgba(120,180,235,0.10) 50%,transparent)",
        }}
      />
      {/* scanline grid */}
      <div
        className="pointer-events-none absolute inset-0 opacity-50"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.025) 1px,transparent 1px)",
          backgroundSize: "100% 26px",
        }}
      />

      {/* nav */}
      <header className="relative z-10 flex items-center justify-between px-[clamp(24px,5vw,72px)] py-[26px]">
        <div className="flex flex-col leading-none">
          <span className="font-display text-[25px] font-extrabold tracking-[-0.045em] text-white">
            Northgate<span className="text-cyan">.</span>
          </span>
          <span className="mt-[3px] font-mono text-[9px] tracking-[0.30em] text-white/55">
            CONSULTING
          </span>
        </div>
        <nav className="hidden items-center gap-[38px] text-[15.5px] font-semibold text-white/90 md:flex">
          {navItems.map((item) => (
            <span key={item} className="flex cursor-pointer items-center gap-1.5">
              {item} <span className="text-[11px] opacity-70">▾</span>
            </span>
          ))}
        </nav>
        <a
          href="#contact"
          className="rounded-full bg-blue px-6 py-[13px] text-[15px] font-bold text-white shadow-[0_8px_24px_rgba(61,90,217,0.40)] transition hover:-translate-y-0.5 hover:shadow-[0_12px_30px_rgba(61,90,217,0.55)]"
        >
          Get in Touch
        </a>
      </header>

      {/* hero copy */}
      <div className="relative z-[5] mx-auto flex w-full max-w-[1320px] flex-1 items-center px-[clamp(24px,5vw,72px)]">
        <div className="max-w-[940px] pb-[7vh]">
          <h1 className="m-0 text-balance font-display text-[clamp(46px,7vw,104px)] font-extrabold leading-[0.98] tracking-[-0.035em]">
            Turning Enterprise
            <br />
            Complexity into <span className="text-cyan">Clarity</span>
          </h1>
          <div className="mt-[30px] font-display text-[clamp(22px,2.6vw,40px)] font-semibold tracking-[-0.01em] text-white/90">
            Reliable<span className="text-cyan">.</span> Resilient
            <span className="text-cyan">.</span> Resolve
            <span className="text-cyan">.</span>
          </div>
          <p className="mt-7 max-w-[520px] text-[clamp(16px,1.25vw,19px)] leading-[1.65] text-white/60">
            From board-level strategy to ground-level delivery — Northgate
            partners with Tier 1–3 service providers to drive sustainable
            transformation.
          </p>
          <div className="mt-[38px] flex flex-wrap gap-4">
            <a
              href="#contact"
              className="flex items-center gap-2.5 rounded-full bg-cyan px-[30px] py-4 text-[16px] font-bold text-[#06203a] shadow-[0_10px_30px_rgba(5,175,242,0.35)] transition hover:-translate-y-0.5"
            >
              Start a Conversation <ArrowRight size={18} />
            </a>
            <a
              href="#engage"
              className="flex items-center gap-2.5 rounded-full border-[1.5px] border-white/30 px-7 py-4 text-[16px] font-semibold text-white transition hover:border-white/50 hover:bg-white/10"
            >
              Explore What We Do
            </a>
          </div>
        </div>
      </div>

      {/* arc: ocean → white band */}
      <Arc
        variant="hero"
        fill="#ffffff"
        heightClass="h-[clamp(60px,7vw,120px)]"
        className="relative z-[4] mt-auto"
      />
    </section>
  );
}
