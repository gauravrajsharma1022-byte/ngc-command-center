import { Play } from "lucide-react";
import { Arc } from "@/components/Arc";

/**
 * joy101-style curved media band. The five panels are brand-gradient
 * placeholders — swap each for an <Image> / <video> as assets arrive
 * (keep `relative overflow-hidden` on the wrapper).
 */

const panels = [
  "radial-gradient(120% 90% at 28% 18%,rgba(120,160,255,0.22),transparent 58%),linear-gradient(150deg,#3d5ad9,#0c1945)",
  "radial-gradient(120% 90% at 70% 22%,rgba(5,175,242,0.20),transparent 60%),linear-gradient(155deg,#1c3d8f,#0a1640)",
  "radial-gradient(90% 80% at 50% 42%,rgba(5,175,242,0.28),transparent 62%),linear-gradient(150deg,#143a86,#0a1438)", // center (video)
  "radial-gradient(120% 90% at 30% 24%,rgba(5,175,242,0.18),transparent 60%),linear-gradient(155deg,#1c3d8f,#0a1640)",
  "radial-gradient(120% 90% at 72% 18%,rgba(120,160,255,0.22),transparent 58%),linear-gradient(150deg,#3d5ad9,#0c1945)",
];

export function ProofBand() {
  return (
    <section
      data-screen-label="Proof"
      className="relative bg-white pb-[clamp(64px,8vw,150px)]"
    >
      <div className="px-6 pt-[clamp(8px,2vw,28px)] pb-[clamp(34px,4vw,56px)] text-center">
        <div className="mb-[18px] font-mono text-[12.5px] tracking-[0.28em] text-blue">
          SEEN IN THE ROOM
        </div>
        <h2 className="mx-auto m-0 max-w-[18ch] text-balance font-display text-[clamp(30px,4vw,54px)] font-extrabold leading-[1.04] tracking-[-0.03em] text-navy">
          Strategy you can watch take shape.
        </h2>
      </div>

      {/* curved full-bleed media strip */}
      <div className="relative w-full overflow-hidden">
        <div className="grid h-[clamp(380px,42vw,580px)] grid-cols-[1fr_1.15fr_1.6fr_1.15fr_1fr] gap-2">
          {panels.map((bg, i) => (
            <div
              key={i}
              className="relative overflow-hidden shadow-[inset_0_0_0_1px_rgba(255,255,255,0.06)]"
              style={{ background: bg }}
            >
              {i === 2 && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <button
                    type="button"
                    aria-label="Play video"
                    className="flex h-[78px] w-[78px] items-center justify-center rounded-full bg-white/95 shadow-[0_12px_44px_rgba(0,0,0,0.5)] transition hover:scale-105"
                  >
                    <Play size={28} className="ml-0.5 fill-navy text-navy" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* arc carves — white, top and bottom */}
        <Arc
          variant="concaveTop"
          fill="#ffffff"
          className="pointer-events-none absolute left-0 top-[-1px] w-full"
        />
        <Arc
          variant="concaveBottom"
          fill="#ffffff"
          className="pointer-events-none absolute bottom-[-1px] left-0 w-full"
        />
      </div>
    </section>
  );
}
