import { MapPin, Mail, Linkedin, ArrowUpRight } from "lucide-react";

const services = [
  "Board & CXO Advisory",
  "Business Consulting",
  "Presales & Postsales",
  "Competitive Intelligence",
  "Vendor Evaluation",
  "Project Management",
  "Digital Transformation",
];
const sectors = ["Telecom Operators", "MVNO / MVNE", "Enterprise", "Healthcare", "Fintech"];
const company = ["Who We Are", "Our Values", "Our Thinking", "Contact"];

function LinkColumn({ title, links }: { title: string; links: string[] }) {
  return (
    <div>
      <div className="mb-[22px] font-mono text-[11.5px] tracking-[0.22em] text-cyan">
        {title}
      </div>
      <div className="flex flex-col gap-[13px] text-[15px] text-[#7a87a6]">
        {links.map((l) => (
          <a key={l} href="#" className="transition hover:text-white">
            {l}
          </a>
        ))}
      </div>
    </div>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-dark px-[clamp(24px,5vw,72px)] pt-[clamp(56px,6vw,90px)]">
      <div className="mx-auto grid max-w-[1240px] grid-cols-1 gap-[clamp(32px,4vw,56px)] sm:grid-cols-2 lg:grid-cols-[1.6fr_1fr_1fr_1.2fr]">
        {/* brand */}
        <div>
          <div className="mb-[22px] flex flex-col leading-none">
            <span className="font-display text-[24px] font-extrabold tracking-[-0.045em] text-white">
              Northgate<span className="text-cyan">.</span>
            </span>
            <span className="mt-[3px] font-mono text-[9px] tracking-[0.30em] text-white/45">
              CONSULTING
            </span>
          </div>
          <p className="m-0 mb-6 max-w-[300px] text-[15px] leading-[1.6] text-[#7a87a6]">
            Empowering telecoms and enterprises to navigate digital
            transformation with clarity, speed, and confidence.
          </p>
          <div className="flex gap-3">
            <a
              href="#"
              aria-label="LinkedIn"
              className="flex h-10 w-10 items-center justify-center rounded-[11px] bg-white/[0.06] text-[#9aa6c4] transition hover:bg-blue hover:text-white"
            >
              <Linkedin size={18} />
            </a>
            <a
              href="#"
              aria-label="Email"
              className="flex h-10 w-10 items-center justify-center rounded-[11px] bg-white/[0.06] text-[#9aa6c4] transition hover:bg-blue hover:text-white"
            >
              <Mail size={18} />
            </a>
          </div>
        </div>

        <LinkColumn title="SERVICES" links={services} />

        <div>
          <div className="mb-[34px]">
            <LinkColumn title="SECTORS" links={sectors} />
          </div>
          <LinkColumn title="COMPANY" links={company} />
        </div>

        {/* contact */}
        <div>
          <div className="mb-[22px] font-mono text-[11.5px] tracking-[0.22em] text-cyan">
            GET IN TOUCH
          </div>
          <div className="mb-4 flex items-start gap-2.5 text-[15px] text-[#7a87a6]">
            <MapPin size={18} className="mt-0.5 flex-none text-cyan" />
            Dubai, UAE &amp; Gurugram, India
          </div>
          <div className="mb-7 flex items-start gap-2.5 text-[15px] text-[#7a87a6]">
            <Mail size={18} className="mt-0.5 flex-none text-cyan" />
            hello@northgateconsulting.com
          </div>
          <a
            href="#"
            className="inline-flex items-center gap-2 rounded-full border-[1.5px] border-cyan/50 px-6 py-[13px] text-[15px] font-bold text-cyan transition hover:bg-cyan/10"
          >
            Start a Conversation <ArrowUpRight size={16} />
          </a>
        </div>
      </div>

      <div className="mx-auto mt-[clamp(48px,5vw,72px)] flex max-w-[1240px] flex-wrap items-center justify-between gap-5 border-t border-white/[0.08] py-[26px]">
        <span className="text-[14px] text-mute-deep">
          © 2026 Northgate Consulting. All rights reserved.
        </span>
        <div className="flex gap-7 text-[14px] text-mute-deep">
          <a href="#" className="transition hover:text-white">
            Privacy Policy
          </a>
          <a href="#" className="transition hover:text-white">
            Terms of Use
          </a>
        </div>
      </div>
    </footer>
  );
}
