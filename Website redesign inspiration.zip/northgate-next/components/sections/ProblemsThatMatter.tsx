"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { SECTORS, type SectorKey } from "@/lib/content";

export function ProblemsThatMatter() {
  const [active, setActive] = useState<SectorKey>("telecom");
  const sector = SECTORS.find((s) => s.key === active)!;

  return (
    <section
      data-screen-label="Problems That Matter"
      className="bg-ink px-[clamp(24px,5vw,72px)] py-[clamp(56px,7vw,110px)]"
    >
      <div className="mx-auto max-w-[1240px]">
        <div className="mb-[22px] font-mono text-[12.5px] tracking-[0.26em] text-cyan">
          — THE PROBLEMS THAT MATTER
        </div>
        <h2 className="m-0 mb-[22px] max-w-[20ch] text-balance font-display text-[clamp(34px,5vw,66px)] font-extrabold leading-none tracking-[-0.03em] text-white">
          Every sector has a sticking point.
          <br />
          <span className="text-cyan">These are the ones we work on.</span>
        </h2>
        <p className="m-0 mb-[clamp(34px,4vw,48px)] max-w-[620px] text-[clamp(15.5px,1.15vw,18px)] leading-[1.65] text-mute">
          We do not arrive with a methodology and a template. We arrive with a
          diagnosis — built from years inside the rooms where these decisions get
          made.
        </p>

        {/* tabs */}
        <div className="mb-[clamp(34px,4vw,48px)] inline-flex gap-1 rounded-full border border-white/[0.08] bg-white/5 p-[5px]">
          {SECTORS.map((s) => {
            const on = s.key === active;
            return (
              <button
                key={s.key}
                type="button"
                onClick={() => setActive(s.key)}
                className={`rounded-full px-[26px] py-[11px] text-[15px] font-semibold transition ${
                  on
                    ? "bg-blue text-white shadow-[0_6px_18px_rgba(61,90,217,0.4)]"
                    : "bg-transparent text-mute hover:text-white"
                }`}
              >
                {s.label}
              </button>
            );
          })}
        </div>

        {/* problem cards */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="wait">
            {sector.cards.map((c, i) => (
              <motion.div
                key={`${active}-${c.n}`}
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.35, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
                className="relative rounded-[18px] border border-white/[0.09] p-[34px]"
                style={{
                  background:
                    "linear-gradient(180deg,rgba(255,255,255,0.025),rgba(255,255,255,0))",
                }}
              >
                <div
                  className="mb-[26px] h-[3px] w-[54px] rounded-[3px]"
                  style={{ background: sector.accent }}
                />
                <div
                  className="mb-[18px] font-mono text-[13px] tracking-[0.18em]"
                  style={{ color: sector.accent }}
                >
                  {c.n}
                </div>
                <h3 className="m-0 mb-[18px] text-balance font-display text-[clamp(19px,1.5vw,22px)] font-bold leading-[1.25] text-white">
                  {c.title}
                </h3>
                <p className="m-0 mb-[26px] text-[15px] leading-[1.62] text-mute">
                  {c.body}
                </p>
                <a
                  href="#"
                  className="inline-flex items-center gap-2 text-[14.5px] font-bold"
                  style={{ color: sector.accent }}
                >
                  How we address this <ArrowRight size={16} />
                </a>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <div className="mt-[clamp(40px,5vw,60px)] flex flex-wrap items-center justify-between gap-[30px] border-t border-white/10 pt-[clamp(32px,4vw,44px)]">
          <span className="text-[clamp(16px,1.3vw,20px)] text-mute">
            Recognise your challenge? We should talk.
          </span>
          <a
            href="#contact"
            className="flex items-center gap-2.5 rounded-full bg-blue px-[30px] py-[15px] text-[16px] font-bold text-white shadow-[0_10px_30px_rgba(61,90,217,0.4)] transition hover:-translate-y-0.5"
          >
            Start a conversation <ArrowRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}
