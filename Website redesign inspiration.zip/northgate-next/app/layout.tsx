import type { Metadata } from "next";
import { Lexend, Source_Sans_3, Geist_Mono } from "next/font/google";
import "./globals.css";

const lexend = Lexend({
  subsets: ["latin"],
  weight: ["500", "600", "700", "800", "900"],
  variable: "--font-lexend",
  display: "swap",
});

const source = Source_Sans_3({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-source",
  display: "swap",
});

const geistMono = Geist_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-geist",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Northgate Consulting — Turning Enterprise Complexity into Clarity",
  description:
    "Telecom & enterprise advisory. From board-level strategy to ground-level delivery, Northgate partners with Tier 1–3 service providers to drive sustainable transformation.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body
        className={`${lexend.variable} ${source.variable} ${geistMono.variable} font-body text-mute antialiased overflow-x-hidden`}
      >
        {children}
      </body>
    </html>
  );
}
