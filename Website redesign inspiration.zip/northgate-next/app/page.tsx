import { Hero } from "@/components/sections/Hero";
import { ProofBand } from "@/components/sections/ProofBand";
import { ActiveIntelligence } from "@/components/sections/ActiveIntelligence";
import { HowWeEngage } from "@/components/sections/HowWeEngage";
import { ProblemsThatMatter } from "@/components/sections/ProblemsThatMatter";
import { CTA } from "@/components/sections/CTA";
import { SiteFooter } from "@/components/sections/SiteFooter";

export default function HomePage() {
  return (
    <main className="bg-ink">
      <Hero />
      <ProofBand />
      <ActiveIntelligence />
      <HowWeEngage />
      <ProblemsThatMatter />
      <CTA />
      <SiteFooter />
    </main>
  );
}
